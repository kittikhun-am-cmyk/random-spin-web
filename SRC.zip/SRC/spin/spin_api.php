<?php
echo json_encode(array("status"=>"success")); 
/*include '../system/class.php';
$use = new classoop;
$spin = $use->spin();*/
?>