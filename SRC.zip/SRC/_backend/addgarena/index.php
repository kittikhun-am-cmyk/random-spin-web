<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>



<center>
    <form action="" method="POST">
        <div class="card">
            <div class="card-body">
                <textarea type="text" name="txt_ei" cols="30" rows="10" class="form-control"> </textarea>
            </div>
            <button class="btn btn-success btn-mm" name="addnaja">กดเพิ่มบัตรการีนา</button>
        </div>
    </form>
</center>

<?php

if (isset($_REQUEST['addnaja'])) {;

    $num_txt = Strlen($_REQUEST['txt_ei']);

    $str_markk = trim($_REQUEST['txt_ei']);
    $str_markk = preg_replace('~\R~u', "\r\n", $str_markk);
    $numrow = substr_count($str_markk, "\n") + 1;

    if ($num_txt < 16) {
        echo "<script>
                 Swal.fire('ขออภัยค่ะ','บัตรการีนามีไม่ต่ำกว่า 16 ตัวค่ะ','error')
              </script>";
    } else {
        $markk_array = array_map('trim', explode("\n", $_REQUEST['txt_ei']));
        // print_r($markk_array);

        for ($x = 0; $x <= $numrow; $x++) {


            $sql = $db->prepare("INSERT INTO `garena_card` (`id`, `price`, `number`) VALUES (NULL, :price, :number)");
            $sql->execute(array(
                ':price' => 20,
                ':number' => $markk_array[$x]
            ));
        }

        echo "<script>
                            swal('เพิ่มบัตรเรียบร้อยแล้วค่ะ !', 'รอ 2 วินาทีเพื่อไปสู่หน้าหลัก', 'success');
                                    setTimeout(function() {
                                        window.location.href = '?admin_page=addgarena';
                                    }, 2000);
                            </script> ";


    }
}

?>



<?php

include('connection.php');
error_reporting(0);

if (isset($_POST['action']) == "addgarena") {

    $price = $_POST['price'];
    $number = $_POST['number'];


    $sql = $db->prepare("INSERT INTO `garena_card` (`id`, `price`, `number`) VALUES (NULL, :price, :number)");
    if ($sql->execute(array(
        ':price' => $price,
        ':number' => $number
    ))) {
        echo "<script>
                            swal('เพิ่มบัตรเรียบร้อยแล้วค่ะ !', 'รอ 2 วินาทีเพื่อไปสู่หน้าหลัก', 'success');
                                    setTimeout(function() {
                                        window.location.href = '?admin_page=addgarena';
                                    }, 2000);
                            </script> ";
    }
}

if (isset($_REQUEST['delete'])) {

    $idnaja = $_REQUEST['delete'];
    // echo $idnaja;

    $sql = $db->prepare("DELETE FROM garena_card WHERE id = :id");
    $sql->execute(array(
        ':id' => $idnaja
    ));
}

?>


<form action="" method="POST">



    <!-- <div class="card">
        <div class="card-body">
            <center>

                <div class="container mt-5">
                    <div class="row">
                        <div class="col-4">
                            <div class="container">
                                <label for=""><b class="" style="font-size: 32px;">เพิ่มการีนา</b></label>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="container">
                                <input type="text" class="form-control" name="price" placeholder="ราคาบัตร">
                            </div>
                        </div>
                        <div class="col-5">
                            <div class="container">
                                <input type="text" class="form-control" name="number" placeholder="กรอกบัตรการีนา เพื่อเพิ่มบัตรลงสต็อก">
                            </div>
                        </div>
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <button class="btn btn-success btn-block mt-5" name="action" value="addgarena">เพิ่มบัตร</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </center>
        </div>
    </div> -->


    <div class="card mt-5">
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th class="text-center">ลำดับ</th>
                        <th>ราคาบัตร</th>
                        <th>รหัสบัตร</th>
                        <th>สถานะ</th>
                    </tr>
                </thead>
                <tbody>


                    <?php

                    $select_stmt = $db->prepare("SELECT * FROM garena_card");
                    $select_stmt->execute();

                    while ($row = $select_stmt->fetch(PDO::FETCH_ASSOC)) {
                    ?>

                        <tr>
                            <td class="text-center"><?= $row['id'] ?></td>
                            <td><?= $row['price'] ?></td>
                            <td><?= $row['number'] ?></td>
                            <td>

                                <a href="?admin_page=addgarena&delete=<?= $row['id'] ?>" class="btn btn-sm btn-danger">
                                    ลบออก
                                </a>

                            </td>
                        </tr>

                    <?php
                    }
                    ?>



                </tbody>
            </table>
        </div>
    </div>

</form>