<?php
require_once('connection.php');
error_reporting(0);
if (isset($_REQUEST['btn_login'])) {
    $username = strip_tags($_REQUEST['username']);
    $password = strip_tags($_REQUEST['password']);

    if (empty($username)) {
        $errorMsg[] = "กรุณากรอก ชื่อผู้ใช้ของท่าน";
    } else if (empty($password)) {
        $errorMsg[] = "กรุณากรอก รหัสผ่านของท่าน";
    } else {
        try {
            $select_stmt = $db->prepare("SELECT * FROM admin_user WHERE username = :username and password = :password");
            $select_stmt->execute(array(
                ':username' => $username,
                ':password' => $password
            ));
            $row = $select_stmt->fetch(PDO::FETCH_ASSOC);

            if ($select_stmt->rowCount() > 0) {
                if ($username == $row['username']) {
                    if ($password) {
                        $_SESSION['admin_login'] = $row['id'];
                        header("location: index.php?admin_page=showstatus");
                    } else {
                        $errorMsg[] = "มีบางอย่างผิดพลาดค่ะ !1";
                    }
                } else {
                    $errorMsg[] = "มีบางอย่างผิดพลาดค่ะ !2";
                }
            } else {
                $errorMsg[] = "มีบางอย่างผิดพลาดค่ะ ! 3";
            }
        } catch (PDOException $e) {
            $e->getMessage();
        }
    }
}


?>

<?php include('include/head.php'); ?>



<div id="main-wrapper">
    <div class="login-register-section section pb-20">
        <div class="container">
            <div class="row">
                <!--Login Form Start-->
                <div class="col-lg-8 offset-sm-2">
                    <div class="customer-login-register">

                        <div class="bg_contentwhite">
                            <h1 class="mt-5">เข้าสู่ระบบ</h1>
                            <hr>



                            <div onclick="">
                                <div id="error">

                                    <!-- ตรวจเช็ค Register & Error -->
                                    <?php
                                    if (isset($errorMsg)) {
                                        foreach ($errorMsg as $error) {
                                    ?>
                                            <div class="alert alert-danger">
                                                <strong><?php echo $error; ?></strong>
                                            </div>
                                    <?php
                                        }
                                    }
                                    ?>

                                    <?php
                                    if (isset($registerMsg)) {
                                    ?>
                                        <div class="alert alert-success">
                                            <strong><?php echo $registerMsg; ?></strong>
                                        </div>
                                    <?php
                                    }
                                    ?>

                                    <?php
                                    if (isset($loginMsg)) {
                                    ?>
                                        <div class="alert alert-success">
                                            <strong><?php echo $loginMsg; ?></strong>
                                        </div>
                                    <?php
                                    }
                                    ?>


                                </div>
                            </div>



                            <form method="POST">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="form-fild">
                                            <input type="hidden" id="affiliate" name="affiliate" value="">
                                            <p><label>Username <span class="">*</span></label></p>
                                            <input type="text" name="username" placeholder="ชื่อบัญชีผู้ใช้งาน" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="form-fild">
                                            <p><label>Password <span class="">*</span></label></p>
                                            <input type="password" name="password" placeholder="รหัสผ่าน" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mt-3">
                                        <div class="login-submit mt-15">
                                            <button type="submit" name="btn_login" class="btn btn-success btn-block">เข้าสู่ระบบ</button>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mt-3">
                                        <div class="login-submit mt-15">
                                            <button type="reset" class="btn btn-danger btn-block">ยกเลิก</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>